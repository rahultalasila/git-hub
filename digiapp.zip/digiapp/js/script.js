// This script handles form validation and provides feedback to the user.

document.addEventListener('DOMContentLoaded', () => {

    // Send Money Form - Handle the submission
    const sendMoneyForm = document.getElementById('send-money-form');
    if (sendMoneyForm) {
        sendMoneyForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const recipient = document.getElementById('recipient').value;
            const amount = document.getElementById('amount').value;

            if (!recipient || !amount) {
                alert("Please fill in all fields!");
                return;
            }

            // Simple validation to ensure amount is a positive number
            if (parseFloat(amount) <= 0) {
                alert("Please enter a valid amount greater than 0.");
                return;
            }

            alert(`Money Sent to ${recipient}!\nAmount: ₹${amount}`);
            sendMoneyForm.reset(); // Reset form fields
        });
    }

    // Add Money Form - Handle the submission
    const addMoneyForm = document.querySelector('form');
    if (addMoneyForm) {
        addMoneyForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const amount = addMoneyForm.querySelector('input[type="number"]').value;

            if (!amount || parseFloat(amount) <= 0) {
                alert("Please enter a valid amount greater than 0.");
                return;
            }

            alert(`₹${amount} Added to Your Wallet!`);
            addMoneyForm.reset(); // Reset form fields
        });
    }

    // Function to handle login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            // Simple login validation
            if (username === "test" && password === "test") {
                alert("Welcome, Test!");
                location.href = "dashboard.html"; // Redirect to homepage
            } else {
                alert("Wrong username or password!");
            }
        });
    }

    // Transaction history section - You can implement this further to fetch real data if needed
    const transactionHistoryButton = document.getElementById('load-history');
    if (transactionHistoryButton) {
        transactionHistoryButton.addEventListener('click', function () {
            alert("Fetching transaction history...");
            // Ideally, you'd fetch this data from your server/database
            // For now, we'll just simulate by showing a message.
        });
    }

    // Function to ensure that buttons are only clickable if form fields are filled
    const sendMoneyButton = document.getElementById('send-money-button');
    if (sendMoneyButton) {
        sendMoneyButton.disabled = true;
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', function () {
                const recipient = document.getElementById('recipient').value;
                const amount = document.getElementById('amount').value;
                sendMoneyButton.disabled = !(recipient && amount);
            });
        });
    }

});
